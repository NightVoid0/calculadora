import time
import os
#Selector de operaciones
    #suma = 1
    #resta = 2
    #multiplicacion = 3
    #division = 4
opcion = -1
numero_uno = 0
numero_dos = 0
resultado = 0
#Seleccionando operaciones
def borrar():
    if os.name == "posix":
        os.system("clear")
    elif os.name == "ce" or os.name == "nt" or os.name == "dos":
        os.system("cls")

    
def operaciones():
    print(chr(27)+"[1;32m"+"""
      _____      _            _           _                 
     / ____|    | |          | |         | |                
    | |     __ _| | ___ _   _| | __ _  __| | ___  _ __ __ _ 
    | |    / _` | |/ __| | | | |/ _` |/ _` |/ _ \| '__/ _` |
    | |___| (_| | | (__| |_| | | (_| | (_| | (_) | | | (_| |
     \_____\__,_|_|\___|\__,_|_|\__,_|\__,_|\___/|_|  \__,_| 
                                                         
                                                         
    """)
    print(chr(27)+"[1;37m"+"""
    Simbologia:

    Suma = 1
    Resta = 2
    Multiplicacion = 3
    Division = 4
    """)

    opcion = int(input("Seleccione la operacion: "))

    #Suma
    if opcion == 1:
        numero_uno = int(input("Seleccione el primer numero: ")) 
        numero_dos = int(input("Seleccione el segundo numero: "))

        resultado = numero_uno + numero_dos

    #Resta
    if opcion == 2:
        numero_uno = int(input("Seleccione el primer numero: ")) 
        numero_dos = int(input("Seleccione el segundo numero: "))

        resultado = numero_uno - numero_dos

    #Mulriplicacion
    if opcion == 3:
        numero_uno = int(input("Seleccione el primer numero: ")) 
        numero_dos = int(input("Seleccione el segundo numero: "))

        resultado = numero_uno * numero_dos

    #Division
    if opcion == 4:
        numero_uno = int(input("Seleccione el primer numero: ")) 
        numero_dos = int(input("Seleccione el segundo numero: "))

        resultado = numero_uno / numero_dos

    #Anti Cierre sin querer
    if opcion < 0 or opcion > 4 or opcion == 0 or opcion == false:
        borrar()
        operaciones()


    print("Resultado: ",resultado)
    time.sleep (1)
    borrar()
    operaciones()
borrar()
operaciones()

